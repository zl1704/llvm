//===- lib/Core/Writer.cpp ------------------------------------------------===//
//
//                             The LLVM Linker
//
// This file is distributed under the University of Illinois Open Source
// License. See LICENSE.TXT for details.
//
//===----------------------------------------------------------------------===//

#include "lld/Core/Writer.h"

namespace lld {

Writer::Writer() = default;

Writer::~Writer() = default;

} // end namespace lld
